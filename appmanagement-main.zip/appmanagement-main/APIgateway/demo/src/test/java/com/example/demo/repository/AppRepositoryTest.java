package com.example.demo.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;

import static org.mockito.Mockito.doThrow;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import org.springframework.test.context.junit4.SpringRunner;


import com.example.demo.entity.App;
import com.example.demo.entity.AppData;


@RunWith(SpringRunner.class)
@RestClientTest(AppRepository.class)
public class AppRepositoryTest 
{
    
    @MockBean
    private AppRepository appRepository;

    @Mock
    private RestTemplate restTemplate;
    
    @Mock
    private RestTemplateBuilder restTemplateBuilder;
        
    
    @BeforeEach
    public void setUp() throws Exception 
    {
        MockitoAnnotations.openMocks(this); // Initialize mocks
        when(restTemplateBuilder.build()).thenReturn(restTemplate); // Mock the behavior of RestTemplateBuilder
        
        // Manually create an instance of AppRepository and inject the mock
        appRepository = new AppRepository(restTemplateBuilder);
        // Set the backendUrl value for testing
        appRepository.backendUrl = "http://mock.backend.url/"; 
    }


    @Test
    public void testRetrieveApp() 
    {
        when(restTemplate.getForObject(anyString(), eq(App.class)))
            .thenReturn(new App("appName", new AppData()));

        App app = appRepository.retrieveApp("appName");
        assertNotNull(app);
        assertThat(app.getAppName()).isEqualTo("appName");
    }
    
    @Test
    public void testRetrieveAppNotFound() 
    {
        doThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND))
            .when(restTemplate).getForObject(eq(appRepository.backendUrl + "appName"), eq(App.class));         
        
        Object  dd;
        
        Exception exception = assertThrows(HttpClientErrorException.class,() ->
        {
        	App app = appRepository.retrieveApp("appName");
        	assertNull(app);
        });
    }
}