package com.example.demo.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.service.AppService;
import com.example.demo.entity.App;
import com.example.demo.entity.AppData;

@ExtendWith(MockitoExtension.class)
public class AppControllerTest 
{

    private MockMvc mockMvc;

    @InjectMocks
    private AppController appController;

    @Mock
    private AppService appService;

    @Test
    public void testRetrieveApp() throws Exception 
    {
        when(appService.retrieveApp("appName"))
            .thenReturn(Optional.of(new App("appName", new AppData())));

        mockMvc = MockMvcBuilders.standaloneSetup(appController).build();

        mockMvc.perform(get("/apps/appName")).andExpect(status().isOk());

    }
    
    @Test
    public void testRetrieveAppNotFound() throws Exception 
    {
        // Mock the behavior to return an empty Optional
        when(appService.retrieveApp("nonExistentAppName")).thenReturn(Optional.empty());

        mockMvc = MockMvcBuilders.standaloneSetup(appController).build();

        // Make a GET request and expect a 404 NOT FOUND status
        mockMvc.perform(get("/apps/nonExistentAppName")).andExpect(status().isNotFound());
    }
}
