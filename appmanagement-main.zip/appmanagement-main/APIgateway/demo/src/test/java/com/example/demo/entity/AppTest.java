package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

import com.example.demo.entity.App;
import com.example.demo.entity.AppData;

public class AppTest 
{
    @Test
    public void testApp() 
    {
        AppData appData = new AppData("path", "owner", true);
        App app = new App("appName", appData);

        assertEquals("appName", app.getAppName());
        assertEquals(appData, app.getAppData());
    }

    @Test
    public void testAppData() 
    {
        AppData appData = new AppData("path", "owner", true);

        assertEquals("path", appData.getAppPath());
        assertEquals("owner", appData.getAppOwner());
        assertEquals(true, appData.isValid());
    }
}