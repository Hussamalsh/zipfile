package com.example.demo.service;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;


import com.example.demo.repository.AppRepository;
import com.example.demo.entity.App;
import com.example.demo.entity.AppData;

@ExtendWith(MockitoExtension.class)
public class AppServiceTest 
{

    @InjectMocks
    private AppService appService;

    @Mock
    private AppRepository appRepository;

    @Test
    public void testRetrieveApp() 
    {
        when(appRepository.retrieveApp("appName"))
            .thenReturn(new App("appName", new AppData()));

        Optional<App> app = appService.retrieveApp("appName");
        assertTrue(app.isPresent());
    }

    @Test
    public void testRetrieveAppNotFound() 
    {
        // Mock the behavior to return null
        when(appRepository.retrieveApp("nonExistentAppName")).thenReturn(null);

        // Call the service method
        Optional<App> app = appService.retrieveApp("nonExistentAppName");

        // Assert that the result is an empty Optional
        assertTrue(app.isEmpty());
    }
}
