package com.example.demo.entity;

public class AppData 
{
    private String appPath;
    private String appOwner;
    private boolean isValid;

    // Default constructor
    public AppData() {
    }

    // Parameterized constructor
    public AppData(String appPath, String appOwner, boolean isValid) {
        this.appPath = appPath;
        this.appOwner = appOwner;
        this.isValid = isValid;
    }

    // Getters and setters
    public String getAppPath() {
        return appPath;
    }

    public void setAppPath(String appPath) {
        this.appPath = appPath;
    }

    public String getAppOwner() {
        return appOwner;
    }

    public void setAppOwner(String appOwner) {
        this.appOwner = appOwner;
    }

    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean isValid) {
        this.isValid = isValid;
    }
}
