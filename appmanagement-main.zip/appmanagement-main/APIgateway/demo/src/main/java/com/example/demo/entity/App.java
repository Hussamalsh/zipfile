package com.example.demo.entity;

public class App 
{
    private String appName;
    private AppData appData;

    // Default constructor
    public App() {}

    // Parameterized constructor
    public App(String appName, AppData appData) 
    {
        this.appName = appName;
        this.appData = appData;
    }

    // Getters and setters
    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public AppData getAppData() {
        return appData;
    }

    public void setAppData(AppData appData) {
        this.appData = appData;
    }
}

