package com.example.demo.repository;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.App;

@Repository
public class AppRepository 
{
    private final RestTemplate restTemplate;
    
    @Autowired
    public AppRepository(RestTemplateBuilder restTemplateBuilder) 
    {
        this.restTemplate = restTemplateBuilder.build();
    }
    
    @Value("${backend.url}")
    protected String backendUrl;
    
    public List<App> getAllApps() 
    {
        try {
            return this.restTemplate.getForObject(backendUrl, List.class);
        } catch (HttpClientErrorException.NotFound ex) 
        {
            return Collections.emptyList();  // Return an empty list if not found
        } catch(Exception ex) 
        {
            throw ex;  // rethrow if it's another kind of HttpClientErrorException
        }
    }
    
    public App retrieveApp(String appName) 
    {
        //return restTemplate.getForObject(backendUrl + appName, App.class);
        try {
            return this.restTemplate.getForObject(backendUrl + appName, App.class);
        } catch (HttpClientErrorException.NotFound ex) 
        {
            return null;  // or throw a custom exception
        }catch(Exception ex) 
        {
            throw ex;  // rethrow if it's another kind of HttpClientErrorException
        }
    }
    
    public App createApp(App app) 
    {
        try {
            return restTemplate.postForObject(backendUrl, app, App.class);
        } catch (HttpClientErrorException.NotFound ex) 
        {
            return null;  // or throw a custom exception
        } catch(Exception ex) 
        {
            throw ex;  // rethrow if it's another kind of HttpClientErrorException
        }
    }

    public boolean updateApp(String appName, App app) 
    {
        try {
            restTemplate.put(backendUrl + appName, app);
            return true;
        } catch (HttpClientErrorException.NotFound ex) 
        {
            return false;
        } catch(Exception ex) 
        {
            throw ex;  // rethrow if it's another kind of HttpClientErrorException
        }
    }

    public boolean deleteApp(String appName) 
    {
        try {
            restTemplate.delete(backendUrl + appName);
            return true;
        } catch (HttpClientErrorException.NotFound ex) 
        {
            return false;
        } catch(Exception ex) 
        {
            throw ex;  // rethrow if it's another kind of HttpClientErrorException
        }
    }
}
