package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.App;
import com.example.demo.service.AppService;

@RestController
@RequestMapping(path = "/apps", produces = "application/json")  // Setting a base path for all endpoints
public class AppController 
{

    @Autowired
    private AppService appService;

    @GetMapping("/")
    public ResponseEntity<List<App>> getAllApps()
    {
        List<App> apps = appService.getAllApps();
        if(!apps.isEmpty()) {
            return ResponseEntity.ok(apps);
        } else {
            return ResponseEntity.noContent().build();  // or you can use .notFound() if you prefer a 404 status when there's no data.
        }
    }
    
    @GetMapping("/{appName}")
    public ResponseEntity<App> retrieveApp(@PathVariable String appName) 
    {
    	return appService.retrieveApp(appName)
                .map(app -> ResponseEntity.ok(app))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    @PostMapping("/")
    public ResponseEntity<App> createApp(@RequestBody App app) 
    {
        App createdApp = appService.createApp(app).orElse(null);
        if(createdApp != null) {
            return ResponseEntity.ok(createdApp);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{appName}")
    public ResponseEntity<Void> updateApp(@PathVariable String appName, @RequestBody App app) 
    {
        boolean isUpdated = appService.updateApp(appName, app);
        if(isUpdated) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{appName}")
    public ResponseEntity<Void> deleteApp(@PathVariable String appName) 
    {
        boolean isDeleted = appService.deleteApp(appName);
        if(isDeleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
}