package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.App;
import com.example.demo.repository.AppRepository;

@Service
public class AppService 
{
    @Autowired
    private AppRepository appRepository;

    public  Optional<App>  retrieveApp(String appName) 
    {
        return Optional.ofNullable(appRepository.retrieveApp(appName));
    }
    
    public List<App> getAllApps() 
    {
        return appRepository.getAllApps();
    }
    
    public Optional<App> createApp(App app)
    {
        return Optional.ofNullable(appRepository.createApp(app));
    }

    public boolean updateApp(String appName, App app) 
    {
        return appRepository.updateApp(appName, app);
    }

    public boolean deleteApp(String appName) 
    {
        return appRepository.deleteApp(appName);
    }
    
}