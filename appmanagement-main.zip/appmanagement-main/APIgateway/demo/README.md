# API Gateway for App Management

## Introduction

The API Gateway is an essential component of the Emirates Airlines SDET Case Study solution. It acts as a bridge between the frontend and the Node.js backend, ensuring secure and scalable backend access.

## Structure

- **Controllers**: Act as the primary interfaces for incoming API requests.
- **Services**: Contain the business logic and facilitate interactions with the repositories.
- **Repositories**: Handle backend communication, including data retrieval and updates via HTTP requests.
- **Entities**: Define the application's data model structures.
- **Properties**: Store configuration details, such as backend URLs.

## Getting Started

### Prerequisites

- **Java**: JDK 17 is required.
- **Maven**: Essential for dependency management and building the project.

### Installation Steps

1. **Clone the Repository**:

   ```bash
   git clone https://github.com/Hussamalsh/appmanagement
   ```

2. **Change Directory**:

   ```bash
   cd path-to-api-gateway
   ```

3. **Build the Project**:
   ```bash
   mvn clean install
   ```

### Execution

1. **Run the API Gateway**:
   ```bash
   mvn spring-boot:run
   ```

The server will start on port `8085` by default, but this can be modified through configurations.

## API Documentation

- **Retrieve App Details**:

  - **Type**: GET
  - **Endpoint**: `/apps/{appName}`
  - **Description**: Fetches details of a specific app based on `appName`.

- **Get All Apps**:

  - **Type**: GET
  - **Endpoint**: `/apps`
  - **Description**: Fetches details of all apps in the system.

- **Create a New App**:

  - **Type**: POST
  - **Endpoint**: `/apps`
  - **Description**: Creates a new app.

- **Update App Details**:

  - **Type**: PUT
  - **Endpoint**: `/apps/{appName}`
  - **Description**: Updates details of a specific app based on `appName`.

- **Delete an App**:

  - **Type**: DELETE
  - **Endpoint**: `/apps/{appName}`
  - **Description**: Deletes a specific app based on `appName`.

## Features

- **API Key Authentication**: The gateway employs API key-based authentication for enhanced security. Requests must include the `X-API-KEY` header with the correct key value = hussam.
- **Swagger UI**: Comprehensive API documentation is accessible at `/swagger-ui.html`, thanks to the Springdoc dependency in `pom.xml`.
- **Spring Boot Actuator**: Provides production-ready tools to monitor and manage the application.
- **Robust Error Handling**: In case of data retrieval issues, the system provides clear error messages to aid in troubleshooting.

## Customization

- **Backend Configuration**: The `application.properties` file contains the backend URL, which can be updated as needed.

## Contributing

We welcome contributions! If you have suggestions or improvements, please fork the repository and submit a pull request.

## Licensing

The project is under the ISC License.

## Credits

Crafted with ❤️ by Hussam Alshammari.
