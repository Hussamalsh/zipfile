# Emirates Airlines SDET Case Study: JSON Data Management Web App

This repository contains the solution for the Emirates Airlines SDET Lead Case Study. The application serves as an interface to interact with a static JSON file, enabling teams to search, delete, and update records. Additionally, an API gateway allows other teams to retrieve data via RESTful calls.

## Project Architecture

- **Frontend**:
  - Technologies: HTML,Javascript and CSS
  - Functionality: Interface to interact with the JSON file.
- **Backend**:
  - Technologies: Node.js
  - Functionality: Handles business logic, interacts with the JSON file.
- **API Gateway**:
  - Technologies: Java, Spring Boot.
  - Functionality: Exposes functionalities to other teams via RESTful APIs.

## Setup & Installation

### Prerequisites

- Node.js
- Java JDK
- Spring Boot

### Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/Hussamalsh/appmanagement
   ```

2. Navigate to the project directory:

   ```bash
   cd path-to-project
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

### Running the Application

1. Start the backend:

   ```bash
   npm start
   ```

2. Start the API gateway:

   ```bash
   ./mvnw spring-boot:run
   ```

3. Open the frontend in a web browser at `path-to-project/sdet/appfontend/index.html`.

## Usage

1. **Frontend**:

   - Use the search bar to find records.
   - Click on a record to view details.
   - Use the delete or update button to modify records.
   - You can create a new record

2. **API Gateway**:
   - Make a GET request to `/apps/appOne` to search records.
   - Documentation for further API routes can be found [here](APIgateway/demo/README.md).

## Security

- Ensure to set up proper authentication and authorization if deploying in a production environment.
- Do not expose sensitive information in the JSON file or through the API.

## Contributing

If you wish to contribute to this project, please fork the repository and submit a pull request.

## Licensing

The project is under the ISC License.

## Credits

Crafted with ❤️ by Hussam Alshammari.
