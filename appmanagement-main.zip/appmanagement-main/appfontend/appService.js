const baseUrl = "http://localhost:3000/api/apps";

export async function retrieveApp(appName) {
    const response = await fetch(`${baseUrl}/${appName}`);
    return handleResponse(response);
}

export async function deleteApp(appName) {
    const response = await fetch(`${baseUrl}/${appName}`, { method: 'DELETE' });
    return handleResponse(response);
}

export async function updateApp(appName, appOwner, isValid) {
    const response = await fetch(`${baseUrl}/${appName}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appOwner, isValid })
    });
    return handleResponse(response);
}

function handleResponse(response) {
    if (response.ok) return response.json();
    return response.json().then(err => Promise.reject(err));
}
