# App Management Frontend

This frontend is a part of the Emirates Airlines SDET Case Study solution. It provides a web interface for users to interact with the backend RESTful API, allowing them to retrieve, delete, and update application records.

## Overview

- **HTML**: Defines the structure and content of the web application.
- **CSS**: Provides styling for the web interface.
- **JavaScript**: Manages the dynamic behavior and interactions with the backend.

## Setup & Installation

### Prerequisites

- Node.js and npm (Node Package Manager)
- A web browser (e.g., Chrome, Firefox, Safari)

### Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/Hussamalsh/appmanagement
   ```

2. Navigate to the frontend directory:

   ```bash
   cd path-to-frontend
   ```

3. Install the required Node.js packages:

   ```bash
   npm install
   ```

### Running the Frontend

1. Start the Node.js server:

   ```bash
   npm start
   ```

2. Open a web browser and navigate to `http://localhost:PORT` (replace `PORT` with the appropriate port number if it's not the default 3000).

## Usage

1. **Retrieve**: Enter the app name and click on the "Retrieve" button to fetch its details.
2. **Delete**: Enter the app name and click on the "Delete" button to remove the record.
3. **Update**: Enter the app name, app owner, and the "Is Valid" status, then click on the "Update" button to modify the record.

## Features

- **Responsive Design**: The design is adaptable and looks good on both desktop and mobile devices.
- **Error Handling**: Proper feedback is provided to the user if there's an error in fetching or updating the data.

## Contributing

If you wish to contribute to this frontend, please fork the repository and submit a pull request.

## License

This project is licensed under the ISC License.

## Credits

Crafted with ❤️ by Hussam Alshammari.
