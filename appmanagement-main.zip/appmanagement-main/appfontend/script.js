const baseUrl = "http://localhost:3000/api/apps";

document.addEventListener("DOMContentLoaded", listAllApps);

function listAllApps() {
    clearError();
    fetch(baseUrl)
        .then(handleResponse)
        .then(data => {
            const appsListDiv = document.getElementById('appsList');
            appsListDiv.innerHTML = ''; // Clear previous list

            // Create a table
            const table = document.createElement('table');

            // Create table header
            const thead = document.createElement('thead');
            const headerRow = document.createElement('tr');
            ['App Name', 'Owner', 'Is Valid', 'App Path'].forEach(text => {
                const th = document.createElement('th');
                th.textContent = text;
                headerRow.appendChild(th);
            });
            thead.appendChild(headerRow);
            table.appendChild(thead);

            // Create table body
            const tbody = document.createElement('tbody');
            data.forEach(app => {
                const row = document.createElement('tr');
                [app.appName, app.appData.appOwner, app.appData.isValid ? 'Yes' : 'No', app.appData.appPath,].forEach(text => {
                    const td = document.createElement('td');
                    td.textContent = text;
                    row.appendChild(td);
                });
                tbody.appendChild(row);
            });
            table.appendChild(tbody);

            appsListDiv.appendChild(table);
        })
        .catch(error => displayError('Error: ' + error.error));
}

function retrieveApp() {
    clearError();
    const appName = document.getElementById('appName').value;
    if (!appName) {
        displayError('App name is required.');
        return;
    }

    fetch(`${baseUrl}/${appName}`)
        .then(handleResponse)
        .then(data => {
            // Populate the appOwner field
            document.getElementById('appOwner').value = data.appData.appOwner;
            // Populate the isValid checkbox
            document.getElementById('isValid').checked = data.appData.isValid;
            // Display the retrieved data
            displayResult(JSON.stringify(data, null, 2));
        })
        .catch(error => displayError('Error: ' + error.error));
}

function deleteApp() {
    clearError();
    const appName = document.getElementById('appName').value;
    if (!appName) {
        displayError('App name is required.');
        return;
    }

    fetch(`${baseUrl}/${appName}`, { method: 'DELETE' })
        .then(handleResponse)
        .then(data => {
            displayResult(JSON.stringify(data, null, 2));
            listAllApps(); // Refresh the list of apps after deleting one
        })
        .catch(error => displayError('Error: ' + error.error));
}

function updateApp() {
    clearError();
    const appName = document.getElementById('appName').value;
    const appOwner = document.getElementById('appOwner').value;
    const isValid = document.getElementById('isValid').checked;

    if (!appName || !appOwner) {
        displayError('App name and owner are required.');
        return;
    }

    fetch(`${baseUrl}/${appName}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appOwner, isValid })
    })
        .then(handleResponse)
        .then(data => {
            displayResult(JSON.stringify(data, null, 2));
            listAllApps(); // Refresh the list of apps after deleting one
        }
        )
        .catch(error => displayError('Error: ' + error.error));
}

function createApp() {
    clearError();
    const appName = document.getElementById('newAppName').value;
    const appPath = document.getElementById('newAppPath').value; // Fetch the app path
    const appOwner = document.getElementById('newAppOwner').value;
    const isValid = document.getElementById('newIsValid').checked;

    if (!appName || !appOwner || !appPath) {
        displayError('App name, app path, and owner are required.');
        return;
    }

    const requestBody = {
        appName: appName,
        appData: {
            appPath: appPath,
            appOwner: appOwner,
            isValid: isValid
        }
    };

    fetch(baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
    })
        .then(handleResponse)
        .then(data => {
            displayResult(JSON.stringify(data, null, 2));
            listAllApps(); // Refresh the list of apps after creating a new one
        })
        .catch(error => displayError('Error: ' + error.error));
}


function displayResult(result) {
    document.getElementById('result').innerText = result;
}

function displayError(error) {
    const errorElement = document.getElementById('error');
    errorElement.innerText = error;
    errorElement.style.display = 'block';
}

function clearError() {
    const errorElement = document.getElementById('error');
    errorElement.innerText = '';
    errorElement.style.display = 'none';
}

function handleResponse(response) {
    if (response.ok) return response.json();
    return response.json().then(err => Promise.reject(err));
}
