const express = require('express');
const AppService = require('../services/AppService');
const logger = require('../logger');

class AppController {
    constructor(appService) {
        this.appService = appService;
        this.router = express.Router();
        this.initializeRoutes();
        logger.info('AppController initialized');
    }

    initializeRoutes() {
        this.router.get('/apps', this.handleAsync((req, res) => this.getAllApps(req, res)));
        this.router.get('/apps/:appName', this.validateAppName, this.handleAsync((req, res) => this.getApp(req, res)));
        this.router.delete('/apps/:appName', this.validateAppName, this.handleAsync((req, res) => this.deleteApp(req, res)));
        this.router.put('/apps/:appName', this.validateUpdateRequestBody, this.handleAsync((req, res) => this.updateApp(req, res)));
        this.router.post('/apps', this.validateCreateRequestBody, this.handleAsync((req, res) => this.createApp(req, res)));

        // Error handler middleware
        this.router.use(this.errorHandler);
    }

    errorHandler(err, req, res, next) {
        logger.error('Error handler middleware called = ' + err.message);
        res.status(500).json({
            error: 'Server error',
            message: err.message
        });
    }

    validateAppName(req, res, next) {
        const { appName } = req.params;
        if (appName === null || appName === "") {
            logger.error('User sent invalid app name');
            return res.status(400).json({ error: 'Invalid app name' });
        }
        next();
    }

    validateUpdateRequestBody(req, res, next) {
        const { appOwner, isValid } = req.body;
        if (typeof appOwner !== 'string' || typeof isValid !== 'boolean') {
            logger.error('User sent invalid request body data');
            return res.status(400).json({ error: 'Invalid request body data' });
        }
        next();
    }

    validateCreateRequestBody(req, res, next) {
        const { appName, appData } = req.body;
        if (!appName || typeof appName !== 'string' || !appData || typeof appData.appOwner !== 'string' || typeof appData.isValid !== 'boolean') {
            logger.error('User sent invalid request body data for creating a new app');
            return res.status(400).json({ error: 'Invalid request body data' });
        }
        next();
    }


    handleAsync(fn) {
        return (req, res, next) => {
            logger.info('Handle async request');
            fn(req, res, next).catch(next);
        }
    }

    getAllApps = async (req, res) => {
        logger.info('Fetching all apps');
        const records = await this.appService.getAll();
        if (records && records.length) {
            logger.info('All apps retrieved');
            res.json(records);
        } else {
            logger.error('No apps found');
            res.status(404).json({ error: 'No apps found' });
        }
    }

    getApp = async (req, res) => {
        const { appName } = req.params;
        logger.info('Get app by name = ' + appName);
        const record = await this.appService.retrieve(appName);
        if (record) {
            logger.info('Get app by name retrieved= ' + appName + ' ' + JSON.stringify(record));
            res.json(record);
        } else {
            logger.error('Get app by name not found= ' + appName);
            res.status(404).json({ error: 'Record not found' });
        }
    }

    deleteApp = async (req, res) => {
        const { appName } = req.params;
        logger.info('Delete app by name = ' + appName);
        const result = await this.appService.delete(appName);
        if (result) {
            logger.info('Delete app by name deleted= ' + appName);
            res.json({ message: 'Record deleted' });
        } else {
            logger.error('Delete app by name not found= ' + appName);
            res.status(404).json({ error: 'Record not found' });
        }
    }

    updateApp = async (req, res) => {
        const { appName } = req.params;
        const { appOwner, isValid } = req.body;
        logger.info('Update app by name = ' + appName);
        const result = await this.appService.update(appName, appOwner, isValid);
        if (result) {
            logger.info('Update app by name updated= ' + appName + ' isValid=' + isValid + ' appOwner=' + appOwner);
            res.json({ message: 'Record updated' });
        } else {
            logger.error('Update app by name not found= ' + appName);
            res.status(404).json({ error: 'Record not found' });
        }
    }

    createApp = async (req, res) => {
        const { appName, appData } = req.body;
        logger.info(`Creating a new app named ${appName}`);
        try {
            const result = await this.appService.create(appName, appData);
            if (result) {
                logger.info(`New app named ${appName} created successfully`);
                res.status(201).json({ message: 'App created successfully' });
            } else {
                logger.error(`Failed to create app named ${appName}`);
                res.status(500).json({ error: 'Failed to create app' });
            }
        } catch (error) {
            logger.error(`Error while creating app: ${error.message}`);
            res.status(400).json({ error: error.message });
        }
    }

}

module.exports = AppController;
