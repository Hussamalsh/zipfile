const assert = require('chai').assert;
const sinon = require('sinon');
const AppService = require('../services/AppService');
const AppRepository = require('../repositories/AppRepository');
const lockfile = require('proper-lockfile');

describe('AppService', () => {
    let appService;
    let appRepository;
    let getAllStub, saveAllStub, lockStub, unlockStub;

    before(() => {
        appRepository = new AppRepository('./EKSdetUseCase.json');
        appService = new AppService(appRepository);

        getAllStub = sinon.stub(appRepository, 'getAll');
        saveAllStub = sinon.stub(appRepository, 'saveAll');
        lockStub = sinon.stub(lockfile, 'lock');
        unlockStub = sinon.stub(lockfile, 'unlock');
    });

    afterEach(() => {
        getAllStub.reset();
        saveAllStub.reset();
        lockStub.reset();
        unlockStub.reset();
    });

    after(() => {
        getAllStub.restore();
        saveAllStub.restore();
        lockStub.restore();
        unlockStub.restore();
    });

    it('should throw an error if the file does not exist', async () => {
        getAllStub.rejects(new Error('ENOENT: no such file or directory, open \'./EKSdetUseCase.json\''));

        try {
            await appService.readJSONData();
            assert.fail('Expected error to be thrown');
        } catch (error) {
            assert.equal(error.message, 'ENOENT: no such file or directory, open \'./EKSdetUseCase.json\'');
        }
    });

    it('should throw an error if the file contains invalid JSON', async () => {
        getAllStub.rejects(new Error('Unexpected token'));

        try {
            await appService.readJSONData();
            assert.fail('Expected error to be thrown');
        } catch (error) {
            assert.include(error.message, 'Unexpected token');
        }
    });

    it('should retrieve app data by app name', async () => {
        const mockData = [
            { appName: 'app1', appData: { appPath: '/path', appOwner: 'owner1', isValid: true } }
        ];
        getAllStub.resolves(mockData);

        const result = await appService.retrieve('app1');
        assert.deepEqual(result, { appName: 'app1', appData: { appPath: '/path', appOwner: 'owner1', isValid: true } });
    });

    it('should delete app data by app name if it exists', async () => {
        const mockData = [
            { appName: 'app1', appData: { appPath: '/path', appOwner: 'owner1', isValid: true } }
        ];
        getAllStub.resolves(mockData);

        const result = await appService.delete('app1');
        assert.isTrue(result);
        assert.isTrue(saveAllStub.calledOnce);
    });

    it('should not delete app data if app name does not exist', async () => {
        const mockData = [
            { appName: 'app1', appData: { appPath: '/path', appOwner: 'owner1', isValid: true } }
        ];
        getAllStub.resolves(mockData);

        const result = await appService.delete('nonexistentApp');
        assert.isFalse(result);
        assert.isFalse(saveAllStub.called);
    });

    it('should update app data by app name if it exists', async () => {
        const mockData = [
            { appName: 'app1', appData: { appPath: '/path', appOwner: 'owner1', isValid: true } }
        ];
        getAllStub.resolves(mockData);

        const result = await appService.update('app1', 'newOwner', false);
        assert.isTrue(result);
        assert.isTrue(saveAllStub.calledOnce);
    });

    it('should not update app data if app name does not exist', async () => {
        const mockData = [
            { appName: 'app1', appData: { appPath: '/path', appOwner: 'owner1', isValid: true } }
        ];
        getAllStub.resolves(mockData);

        const result = await appService.update('nonexistentApp', 'newOwner', false);
        assert.isFalse(result);
        assert.isFalse(saveAllStub.called);
    });

    it('should ensure file is locked before reading or writing', async () => {
        const mockData = [
            { appName: 'app1', appData: { appPath: '/path', appOwner: 'owner1', isValid: true } }
        ];
        getAllStub.resolves(mockData);

        const result = await appService.retrieve('app1');
        assert.isTrue(lockStub.calledBefore(getAllStub));
        assert.isTrue(unlockStub.calledAfter(getAllStub));
    });
});
