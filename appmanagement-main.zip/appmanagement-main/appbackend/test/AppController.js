const chai = require('chai');
const chaiHttp = require('chai-http');
const express = require('express');
const sinon = require('sinon');
const AppController = require('../controllers/AppController');
const AppService = require('../services/AppService');

const { expect } = chai;
chai.use(chaiHttp);

describe('AppController', () => {
    let app, appController, mockAppService;

    const sampleAppData = {
        appName: 'app1',
        appData: { appPath: '/path', appOwner: 'owner1', isValid: true }
    };

    beforeEach(() => {
        mockAppService = sinon.createStubInstance(AppService);
        appController = new AppController(mockAppService);
        app = express();
        app.use(express.json());
        app.use('/api', appController.router);
    });

    afterEach(() => {
        sinon.restore(); // Cleanup mocks and stubs
    });

    describe('GET /apps/:appName', () => {
        it('should retrieve app data by app name', async () => {
            mockAppService.retrieve.resolves(sampleAppData);

            const res = await chai.request(app).get('/api/apps/app1');

            expect(res).to.have.status(200);
            expect(res.body).to.deep.equal(sampleAppData);
        });

        it('should handle service errors', async () => {
            mockAppService.retrieve.rejects(new Error('Service error'));

            const res = await chai.request(app).get('/api/apps/app1');

            expect(res).to.have.status(500);
            expect(res.body).to.deep.equal({ error: 'Server error', message: 'Service error' });
        });
    });

    describe('DELETE /apps/:appName', () => {
        it('should delete app data by app name if it exists', async () => {
            mockAppService.delete.resolves(true);

            const res = await chai.request(app).delete('/api/apps/app1');

            expect(res).to.have.status(200);
            expect(res.body).to.deep.equal({ message: 'Record deleted' });
        });

        it('should not delete app data if app name does not exist', async () => {
            mockAppService.delete.resolves(false);

            const res = await chai.request(app).delete('/api/apps/nonexistentApp');

            expect(res).to.have.status(404);
            expect(res.body).to.deep.equal({ error: 'Record not found' });
        });

        it('should handle service errors during delete', async () => {
            mockAppService.delete.rejects(new Error('Service error'));

            const res = await chai.request(app).delete('/api/apps/app1');

            expect(res).to.have.status(500);
            expect(res.body).to.deep.equal({ error: 'Server error', message: 'Service error' });
        });
    });

    describe('PUT /apps/:appName', () => {
        it('should update app data by app name if it exists', async () => {
            mockAppService.update.resolves(true);

            const res = await chai.request(app)
                .put('/api/apps/app1')
                .send({ appOwner: 'newOwner', isValid: false });

            expect(res).to.have.status(200);
            expect(res.body).to.deep.equal({ message: 'Record updated' });
        });

        it('should not update app data if app name does not exist', async () => {
            mockAppService.update.resolves(false);

            const res = await chai.request(app)
                .put('/api/apps/nonexistentApp')
                .send({ appOwner: 'newOwner', isValid: false });

            expect(res).to.have.status(404);
            expect(res.body).to.deep.equal({ error: 'Record not found' });
        });

        it('should handle service errors during update', async () => {
            mockAppService.update.rejects(new Error('Service error'));

            const res = await chai.request(app)
                .put('/api/apps/app1')
                .send({ appOwner: 'newOwner', isValid: false });

            expect(res).to.have.status(500);
            expect(res.body).to.deep.equal({ error: 'Server error', message: 'Service error' });
        });

        it('should handle invalid body data', async () => {
            const res = await chai.request(app)
                .put('/api/apps/app1')
                .send({ appOwner: 12345, isValid: 'invalidBoolean' });

            expect(res).to.have.status(400);
        });
    });
});
