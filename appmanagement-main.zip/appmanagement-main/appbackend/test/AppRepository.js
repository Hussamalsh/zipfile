const assert = require('chai').assert;
const sinon = require('sinon');
const fs = require('fs').promises;
const AppRepository = require('../repositories/AppRepository');

describe('AppRepository', () => {
    let appRepository;
    let fsReadStub, fsWriteStub;

    before(() => {
        appRepository = new AppRepository('./EKSdetUseCase.json');

        fsReadStub = sinon.stub(fs, 'readFile');
        fsWriteStub = sinon.stub(fs, 'writeFile');
    });

    afterEach(() => {
        fsReadStub.reset();
        fsWriteStub.reset();
    });

    after(() => {
        fsReadStub.restore();
        fsWriteStub.restore();
    });

    describe('getAll()', () => {
        it('should return parsed data from file', async () => {
            const mockData = JSON.stringify([{ appName: 'testApp', appData: 'testData' }]);
            fsReadStub.resolves(mockData);

            const result = await appRepository.getAll();
            assert.deepEqual(result, [{ appName: 'testApp', appData: 'testData' }]);
        });

        it('should throw an error if the file contains invalid JSON', async () => {
            fsReadStub.resolves('{ invalidJSON: true, }');

            try {
                await appRepository.getAll();
                assert.fail('Expected error to be thrown');
            } catch (error) {
                assert.include(error.message, 'Unexpected token');
            }
        });

        it('should propagate file system errors', async () => {
            fsReadStub.rejects(new Error('File not found'));

            try {
                await appRepository.getAll();
                assert.fail('Expected error to be thrown');
            } catch (error) {
                assert.equal(error.message, 'File not found');
            }
        });
    });

    describe('saveAll(data)', () => {
        it('should write provided data to file as JSON', async () => {
            const mockData = [{ appName: 'testApp', appData: 'testData' }];
            await appRepository.saveAll(mockData);

            assert.isTrue(fsWriteStub.calledOnce);
            assert.isTrue(fsWriteStub.calledWith('./EKSdetUseCase.json', JSON.stringify(mockData)));
        });

        it('should propagate file system errors', async () => {
            fsWriteStub.rejects(new Error('Write error'));

            try {
                await appRepository.saveAll([{ appName: 'testApp', appData: 'testData' }]);
                assert.fail('Expected error to be thrown');
            } catch (error) {
                assert.equal(error.message, 'Write error');
            }
        });
    });
});
