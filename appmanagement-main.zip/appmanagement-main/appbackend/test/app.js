const assert = require('assert');

const App = require('../models/App');
const AppData = require('../models/AppData');


describe('AppData Model', () => 
{
    it('should create an instance with given parameters', () => {
        const appData = new AppData('path/to/app', 'ownerName', true);
        assert.strictEqual(appData.appPath, 'path/to/app');
        assert.strictEqual(appData.appOwner, 'ownerName');
        assert.strictEqual(appData.isValid, true);
    });
});

describe('App Model', () => 
{
    it('should create an instance with given parameters', () => {
        const appDataInstance = new AppData('path/to/app', 'ownerName', true);
        const app = new App('appName', appDataInstance);
        assert.strictEqual(app.appName, 'appName');
        assert.strictEqual(app.appData, appDataInstance);
    });
    
    it('should create an instance with AppData object when plain object is passed', () => {
        const appDataObject = { appPath: 'path/to/app', appOwner: 'ownerName', isValid: true };
        const app = new App('appName', appDataObject);
        assert.strictEqual(app.appName, 'appName');
        assert.strictEqual(app.appData instanceof AppData, true);
        assert.strictEqual(app.appData.appPath, 'path/to/app');
    });
});
