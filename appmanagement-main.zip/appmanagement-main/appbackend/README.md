# JSON Data Management Backend

This backend is a part of the Emirates Airlines SDET Case Study solution. It provides a RESTful API to interact with a static JSON file, allowing for operations such as search, delete, update, retrieve, and create new application records.

## Overview

- **Controllers**: Manages routes and request-response handling.
- **Models**: Defines the structure of the application and application data.
- **Services**: Handles the business logic, including reading and writing to the JSON file.

## Setup & Installation

### Prerequisites

- [Node.js](https://nodejs.org/en/download/)

### Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/Hussamalsh/appmanagement
   ```

2. Navigate to the project directory:

   ```bash
   cd path-to-backend
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

### Running the Application

1. Start the server:
   ```bash
   npm start
   ```

The server will start and listen on `http://localhost:3000`.

## API Endpoints

1. **GET**: `/api/apps` - Retrieve all apps in the system.
2. **GET**: `/api/apps/:appName` - Retrieve a specific app by `appName`.
3. **POST**: `/api/apps` - Create a new app.
4. **DELETE**: `/api/apps/:appName` - Delete a specific app by `appName`.
5. **PUT**: `/api/apps/:appName` - Update a specific app by `appName`.

## Contributing

If you wish to contribute to this backend, please fork the repository and submit a pull request.

## License

This project is licensed under the ISC License.

## Credits

Crafted with ❤️ by Hussam Alshammari.
