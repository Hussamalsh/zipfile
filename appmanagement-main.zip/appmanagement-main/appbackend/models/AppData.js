class AppData 
{
    constructor(appPath, appOwner, isValid) 
    {
      this.appPath = appPath; // Fixed, cannot be modified
      this.appOwner = appOwner; // Dynamic, can be modified
      this.isValid = isValid; // Dynamic, can be modified
    }
}

module.exports = AppData;
