const AppData = require('./AppData');

class App {
  constructor(appName, appData) {
    this.appName = appName; // Fixed, cannot be modified
    this.appData = appData instanceof AppData ? appData : new AppData(appData.appPath, appData.appOwner, appData.isValid);
  }
}

module.exports = App;
