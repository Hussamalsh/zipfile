const express = require('express');
var morgan = require('morgan')
const cors = require('cors');

const AppRepository = require('./repositories/AppRepository');
const AppService = require('./services/AppService');
const AppController = require('./controllers/AppController');

const appRepository = new AppRepository('EKSdetUseCase.json');
const appService = new AppService(appRepository);
const appController = new AppController(appService);

const app = express();
app.use(morgan('combined')) // Log all requests
app.use(cors()); // Enable CORS for all routes
app.use(express.json());

app.use('/api', appController.router);

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
