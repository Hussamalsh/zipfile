const fs = require('fs').promises;
const logger = require('../logger');

class AppRepository {
    constructor(filePath) {
        this.filePath = filePath;
        logger.info('AppRepository initialized');
    }

    async getAll() {
        const data = await fs.readFile(this.filePath, 'utf-8');
        return JSON.parse(data);
    }

    async saveAll(data) {
        await fs.writeFile(this.filePath, JSON.stringify(data));
    }
}

module.exports = AppRepository;