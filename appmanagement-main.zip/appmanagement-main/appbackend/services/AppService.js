const App = require('../models/App');
const lockfile = require('proper-lockfile');
const logger = require('../logger');

class AppService {
    constructor(repository) {
        this.repository = repository;
        logger.info('AppService initialized');
    }

    async readJSONData() {
        const data = await this.repository.getAll();
        return data.map(item => new App(item.appName, item.appData));
    }

    async getAll() {
        await lockfile.lock(this.repository.filePath);
        logger.info(`AppService - calling GetAll method to retrieve all apps`);
        try {
            const data = await this.readJSONData();
            return data;
        } finally {
            await lockfile.unlock(this.repository.filePath);
        }
    }


    async retrieve(appName) {
        await lockfile.lock(this.repository.filePath);
        logger.info(`AppService - calling Retrieve method to get data for app ${appName}`);
        try {
            const data = await this.readJSONData();
            return data.find(item => item.appName === appName);
        } finally {
            await lockfile.unlock(this.repository.filePath);
        }
    }

    async delete(appName) {
        await lockfile.lock(this.repository.filePath);
        logger.info(`AppService - calling Delete method to delete the app ${appName}`);
        try {
            let data = await this.readJSONData();
            const index = data.findIndex(item => item.appName === appName);
            if (index !== -1) {
                data.splice(index, 1);
                await this.repository.saveAll(data);
                return true;
            }
            return false;
        } finally {
            await lockfile.unlock(this.repository.filePath);
        }
    }

    async update(appName, appOwner, isValid) {
        await lockfile.lock(this.repository.filePath);
        logger.info(`AppService - calling Update method to update data for app ${appName}`);
        try {
            const data = await this.readJSONData();
            const record = data.find(item => item.appName === appName);
            if (record) {
                record.appData.appOwner = appOwner;
                record.appData.isValid = isValid;
                await this.repository.saveAll(data);
                return true;
            }
            return false;
        } finally {
            await lockfile.unlock(this.repository.filePath);
        }
    }

    async create(appName, appData) {
        await lockfile.lock(this.repository.filePath);
        logger.info(`AppService - calling Create method to create a new app named ${appName}`);
        try {
            const data = await this.readJSONData();
            const exists = data.some(item => item.appName === appName);
            if (exists) {
                throw new Error('App with this name already exists');
            }
            data.push({ appName, appData });
            await this.repository.saveAll(data);
            return true;
        } finally {
            await lockfile.unlock(this.repository.filePath);
        }
    }

}

module.exports = AppService;
